# Databricks notebook source
# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("p_data_source", "")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_date", "2021-03-28")
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

pitstops_schema = StructType(fields = [StructField("raceId", IntegerType()), 
                                       StructField("driverId", IntegerType()), 
                                       StructField("stop", IntegerType()), 
                                       StructField("lap", IntegerType()), 
                                       StructField("time", StringType()),
                                       StructField("duration", StringType()),
                                       StructField("milliseconds", IntegerType())
                                       ])

# COMMAND ----------

pitstops_df = spark.read.schema(pitstops_schema).option("multiLine", True).json(f"{raw_folder_path}/{v_file_date}/pit_stops.json")

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

final_df = pitstops_df.withColumnRenamed("driverId", "driver_id").withColumnRenamed("raceId", "race_id").withColumn("ingest_date", current_timestamp()).withColumn("data_source", lit(v_data_source)).withColumn("file_date", lit(v_file_date))

# COMMAND ----------

# pitstops_deduped_df = final_df.dropDuplicates(["race_id","driver_id"])

# COMMAND ----------

# MAGIC %sql
# MAGIC --DROP TABLE f1_processed.pit_stops;

# COMMAND ----------

# overwrite_partition(final_df, "f1_processed", "pit_stops", "race_id")

# COMMAND ----------

merge_condition = "tgt.race_id = src.race_id AND tgt.driver_id = src.driver_id AND tgt.stop = src.stop AND tgt.race_id = src.race_id"
merge_delta_data(final_df, "f1_processed", "pit_stops", processed_folder_path, merge_condition, "race_id")

# COMMAND ----------

dbutils.notebook.exit("Success")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT race_id, COUNT(1) FROM f1_processed.pit_stops GROUP BY race_id ORDER BY race_id DESC;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_processed.pit_stops;

# COMMAND ----------

