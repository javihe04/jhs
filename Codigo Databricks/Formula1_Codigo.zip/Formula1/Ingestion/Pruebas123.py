# Databricks notebook source
from pyspark.sql.types import *

# COMMAND ----------

ingestionMode_schema = StructType(fields = [StructField("value", StringType())])

# COMMAND ----------

tableInput_schema = StructType(fields = [StructField("table", StringType())])

# COMMAND ----------

dataset_schema = StructType(fields = [StructField("name", StringType()),
                                        StructField("ingestionMode", ingestionMode_schema), 
                                       StructField("table", StringType()),
                                       StructField("tableInput", tableInput_schema),                                        
                                       StructField("number", IntegerType()), 
                                       StructField("position", IntegerType()),
                                       StructField("q1", StringType()),
                                       StructField("q2", StringType()),
                                       StructField("q3", StringType()),
                                       ])

# COMMAND ----------

qualifying_df = spark.read.schema(qualifying_schema).option("multiLine", True).json("abfss://raw@formula1dljhs.dfs.core.windows.net/qualifying")

# COMMAND ----------

display(qualifying_df)
# Solo muestra las 10.000 primeras filas

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

final_df = qualifying_df.withColumnRenamed("qualifyingId","qualifying_id").withColumnRenamed("driverId", "driver_id").withColumnRenamed("raceId", "race_id").withColumnRenamed("constructorId", "constructor_id").withColumn("ingest_date", current_timestamp())

# COMMAND ----------

final_df.write.mode("overwrite").parquet("abfss://processed@formula1dljhs.dfs.core.windows.net/qualifying")

# COMMAND ----------

display(spark.read.parquet("abfss://processed@formula1dljhs.dfs.core.windows.net/qualifying"))

# COMMAND ----------

