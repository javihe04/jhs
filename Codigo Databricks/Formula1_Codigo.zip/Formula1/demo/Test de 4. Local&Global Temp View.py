# Databricks notebook source
# Deberia dar error
%sql
SELECT * FROM v_race_results

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM global_temp.gv_race_results;

# COMMAND ----------

