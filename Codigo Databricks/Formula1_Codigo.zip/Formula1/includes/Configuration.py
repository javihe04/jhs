# Databricks notebook source
raw_folder_path = "abfss://raw@formula1dljhs.dfs.core.windows.net"
processed_folder_path = "abfss://processed@formula1dljhs.dfs.core.windows.net"
presentation_folder_path = "abfss://presentation@formula1dljhs.dfs.core.windows.net"

# COMMAND ----------

